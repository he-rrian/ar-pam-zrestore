"""训练前的数据管线自检：不需要 torch，直接看归一化/模拟是否合理。"""

import glob
import os
import re

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import (IMS_M4_NPY, PAM_M4_TXT_DIR, LS_M4_Y_START, TARGET_Z,
                    PSF_SIGMA_Z, PSF_SIGMA_X, ATT_EXP)
from data_reader import LightsheetReader, PamReader, compute_ls_stats
from simulate import generate_pseudo_pam


def main():
    stats = compute_ls_stats(IMS_M4_NPY, n_samples=12)
    print("LS stats: bg=%.1f gain=%.1f col_profile_std=%.2f" % (
        stats["bg"], stats["gain"], float(stats["col_profile"].std())))

    reader = LightsheetReader(IMS_M4_NPY, stats=stats)
    y_ls = 2350  # npy 行号；物理上约 4.94 mm
    ls = reader.get_xz(y_ls + LS_M4_Y_START, 0)
    pseudo, target, clean = generate_pseudo_pam(
        ls, rng=np.random.default_rng(0),
        sigma_z=PSF_SIGMA_Z, sigma_x=PSF_SIGMA_X, att_exp=ATT_EXP,
    )

    files = sorted(glob.glob(os.path.join(PAM_M4_TXT_DIR, "*.txt")),
                   key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))
    bg, gain = PamReader.calibrate(files, n=24)
    print("PAM stats: bg=%.6f gain=%.6f" % (bg, gain))
    pam = PamReader.get_xz(files[500], bg=None, gain=gain)

    for name, img in [("LS target", target), ("pseudo", pseudo), ("real PAM", pam)]:
        print("%-9s mean %.4f  p50 %.4f  p99 %.4f  max %.4f  gradZ %.4f  gradX %.4f" % (
            name, img.mean(), np.median(img), np.percentile(img, 99), img.max(),
            np.abs(np.diff(img, axis=0)).mean(), np.abs(np.diff(img, axis=1)).mean()))

    fig, ax = plt.subplots(2, 3, figsize=(18, 8))
    for a, img, t in zip(ax[0], [target, pseudo, pam],
                         ["LS target (new norm)", "pseudo-PAM", "real PAM (global norm)"]):
        a.imshow(img, cmap="magma", aspect="auto", vmin=0, vmax=1)
        a.set_title(t)
        a.set_xlabel("X")
        a.set_ylabel("Z")

    ax[1, 0].hist(target.ravel(), bins=100, range=(0, 1), alpha=0.6, label="LS target")
    ax[1, 0].hist(pseudo.ravel(), bins=100, range=(0, 1), alpha=0.6, label="pseudo")
    ax[1, 0].hist(pam.ravel(), bins=100, range=(0, 1), alpha=0.6, label="real PAM")
    ax[1, 0].set_yscale("log")
    ax[1, 0].legend()
    ax[1, 0].set_title("histograms")

    col = int(np.argmax(target.max(axis=0)))
    ax[1, 1].plot(target[:, col], label="LS target", lw=1)
    ax[1, 1].plot(pseudo[:, col], label="pseudo", lw=1)
    ax[1, 1].plot(pam[:, col], label="real PAM", lw=1)
    ax[1, 1].legend()
    ax[1, 1].set_title(f"axial profile X={col}")

    ax[1, 2].imshow(np.maximum(target - pseudo, 0), cmap="magma", aspect="auto")
    ax[1, 2].set_title("target - pseudo (positive part)")

    plt.tight_layout()
    plt.savefig("verify_preprocess.png", dpi=170)
    print("saved verify_preprocess.png")


if __name__ == "__main__":
    main()
