import numpy as np, glob, re, os
from scipy.signal import hilbert
from scipy.ndimage import gaussian_filter1d

files = sorted(glob.glob("data/4/*.txt"), key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))
for fi in [0, 200, 500, 800, 997]:
    rf = np.loadtxt(files[fi], dtype=np.float32).T
    rf -= rf.mean(0, keepdims=True)
    env = np.abs(hilbert(rf, axis=0))
    prof = gaussian_filter1d(env.mean(axis=1), 3)
    mx = prof.max()
    # first sample above 20% of max, and argmax
    above = np.where(prof > 0.2 * mx)[0]
    print("frame %3d: argmax sample %3d, first>20%% sample %3d, profile[0:220:20] = %s" % (
        fi, int(np.argmax(prof)), int(above[0]) if len(above) else -1,
        np.round(prof[0:220:20] / mx, 2).tolist()))
    # print fine profile 80..220
    print("   fine 80..220 (every 10):", np.round(prof[80:221:10] / mx, 3).tolist())
