import os
import re
import glob
import torch
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tqdm import tqdm
from data_reader import PamReader
from model import AxialNAFNet
from config import *

# ================= 1. 构建声光缓存 =================
def build_cache(txt_dir, out_npy):
    if os.path.exists(out_npy):
        print(f"✅ 缓存 {out_npy} 已存在，跳过构建。")
        return
        
    files = glob.glob(os.path.join(txt_dir, "*.txt"))
    files = [f for f in files if re.search(r"\d+", os.path.basename(f)) and not os.path.basename(f).startswith(".")]
    files = sorted(files, key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))

    print(f"正在构建缓存 {out_npy}，共 {len(files)} 个文件...")
    cache = np.zeros((len(files), TARGET_Z, TARGET_X), dtype=np.float32)
    for i, f in enumerate(tqdm(files, desc="Building Cache")):
        cache[i] = PamReader.get_xz(f)
    np.save(out_npy, cache)
    print(f"✅ 缓存已保存至 {out_npy}")

# ================= 2. 核心推理逻辑 =================
def run_inference(cache_path, model_path, out_npy, batch_size=8):
    model = AxialNAFNet().cuda()
    # 兼容不同 PyTorch 版本
    try:
        sd = torch.load(model_path, map_location="cuda:0", weights_only=True)
    except TypeError:
        sd = torch.load(model_path, map_location="cuda:0")
    model.load_state_dict(sd)
    model.eval()

    pam_cache = np.load(cache_path)
    num_slices = pam_cache.shape[0]
    output_volume = np.zeros_like(pam_cache)

    with torch.no_grad():
        for b_start in tqdm(range(0, num_slices, batch_size), desc=f"Inference {os.path.basename(out_npy)}"):
            b_end = min(b_start + batch_size, num_slices)
            batch_list = []
            for i in range(b_start, b_end):
                # 2.5D 输入：前后各取两层
                channels = [pam_cache[np.clip(i + offset, 0, num_slices - 1)]
                            for offset in [-2, -1, 0, 1, 2]]
                batch_list.append(np.stack(channels, axis=0))
            batch_tensor = torch.from_numpy(np.stack(batch_list, axis=0)).cuda()
            pred = model(batch_tensor)
            output_volume[b_start:b_end] = pred.squeeze(1).cpu().numpy()

    np.save(out_npy, output_volume)
    print(f"✅ 推理结果已保存至 {out_npy}")

# ================= 3. 自动可视化对比 =================
def visualize_results(cache_path, enh_path, mouse_name):
    raw = np.load(cache_path)
    enh = np.load(enh_path)
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    raw_mip = np.max(raw, axis=1)
    enh_mip = np.max(enh, axis=1)
    
    axes[0].imshow(raw_mip, cmap='magma', aspect='auto')
    axes[0].set_title(f"{mouse_name} Raw PAM - XY MIP")
    axes[0].axis('off')
    
    axes[1].imshow(enh_mip, cmap='magma', aspect='auto')
    axes[1].set_title(f"{mouse_name} Enhanced PAM - XY MIP")
    axes[1].axis('off')
    
    plt.tight_layout()
    plt.savefig(f"result_{mouse_name}_MIP.png", dpi=200)
    plt.close()

    # XZ 切面对比
    y_samples = [200, 500, 800]
    fig, axes = plt.subplots(len(y_samples), 2, figsize=(12, 3 * len(y_samples)))
    for idx, y in enumerate(y_samples):
        y_idx = min(y, len(raw) - 1)
        axes[idx, 0].imshow(raw[y_idx], cmap='magma', aspect='auto')
        axes[idx, 0].set_title(f"{mouse_name} Raw (Y={y_idx})")
        
        axes[idx, 1].imshow(enh[y_idx], cmap='magma', aspect='auto')
        axes[idx, 1].set_title(f"{mouse_name} Enhanced (Y={y_idx})")
    plt.tight_layout()
    plt.savefig(f"result_{mouse_name}_XZ.png", dpi=200)
    plt.close()
    print(f"✅ {mouse_name} 可视化对比图已保存！")

# ================= 4. 主流程 =================
if __name__ == "__main__":
    MODEL_PATH = "best_mfixed.pth"
    
    # 1. 准备小鼠 4（训练域）的缓存与推理
    print("\n=== 处理 小鼠 4 (同分布测试) ===")
    build_cache(PAM_M4_TXT_DIR, CACHE_M4_PATH)
    OUT_M4 = os.path.join(DATA_DIR, "mouse4_enhanced.npy")
    run_inference(CACHE_M4_PATH, MODEL_PATH, OUT_M4)
    visualize_results(CACHE_M4_PATH, OUT_M4, "Mouse4")

    # 2. 准备小鼠 1（跨样本泛化测试）的缓存与推理
    print("\n=== 处理 小鼠 1 (跨样本泛化测试) ===")
    build_cache(PAM_M1_TXT_DIR, CACHE_M1_PATH)
    OUT_M1 = os.path.join(DATA_DIR, "mouse1_enhanced.npy")
    run_inference(CACHE_M1_PATH, MODEL_PATH, OUT_M1)
    visualize_results(CACHE_M1_PATH, OUT_M1, "Mouse1")

    print("\n🎉 所有测试与可视化全部完成！请查看 result_Mouse4_*.png 和 result_Mouse1_*.png")