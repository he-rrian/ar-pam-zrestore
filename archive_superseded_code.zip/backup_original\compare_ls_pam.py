import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
from config import *
from data_reader import LightsheetReader

def compare_ls_vs_pam(ls_npy_path, raw_pam_path, enh_pam_path, mouse_name="Mouse4"):
    # 1. 加载 PAM 数据
    raw = np.load(raw_pam_path)
    enh = np.load(enh_pam_path)
    ls_reader = LightsheetReader(ls_npy_path)
    
    # 选取几个包含丰富血管的 Y 层（可以根据实际情况调整）
    y_samples = [200, 500, 800]
    
    fig, axes = plt.subplots(len(y_samples), 3, figsize=(18, 5 * len(y_samples)))
    fig.suptitle(f"{mouse_name}: Light-Sheet vs Raw PAM vs Enhanced PAM", fontsize=20)

    for i, y_idx in enumerate(y_samples):
        # --- 左边：光片真值 (Ground Truth) ---
        # 获取光片数据，读取 4766 宽度并自动降采样到 1000
        ls_xz = ls_reader.get_xz(y_idx + LS_M4_Y_START, LS_M4_X_START)
        
        # --- 中间：原始声光 (Raw PAM) ---
        # 为防止越界，clip 一下索引
        p_idx = min(y_idx, len(raw) - 1)
        raw_img = raw[p_idx]
        
        # --- 右边：增强声光 (Enhanced PAM) ---
        enh_img = enh[p_idx]

        # 画图
        axes[i, 0].imshow(ls_xz, cmap='magma', aspect='auto')
        axes[i, 0].set_title(f"Light-Sheet GT (Y={y_idx})")
        axes[i, 0].set_ylabel("Depth Z")
        
        axes[i, 1].imshow(raw_img, cmap='magma', aspect='auto')
        axes[i, 1].set_title(f"Raw PAM (Y={p_idx})")
        
        axes[i, 2].imshow(enh_img, cmap='magma', aspect='auto')
        axes[i, 2].set_title(f"Enhanced PAM (Y={p_idx})")

    plt.tight_layout()
    plt.savefig(f"compare_LS_PAM_{mouse_name}.png", dpi=250)
    plt.close()
    print(f"✅ 终极对比图已保存：compare_LS_PAM_{mouse_name}.png")

if __name__ == "__main__":
    # 小鼠 4
    compare_ls_vs_pam(
        ls_npy_path=IMS_M4_NPY,
        raw_pam_path=CACHE_M4_PATH,
        enh_pam_path=os.path.join(DATA_DIR, "mouse4_enhanced.npy"),
        mouse_name="Mouse4"
    )
    
    # 小鼠 1
    compare_ls_vs_pam(
        ls_npy_path=IMS_M1_NPY,
        raw_pam_path=CACHE_M1_PATH,
        enh_pam_path=os.path.join(DATA_DIR, "mouse1_enhanced.npy"),
        mouse_name="Mouse1"
    )