import glob
import os
import re

import numpy as np
from scipy.signal import hilbert
from scipy.ndimage import zoom, gaussian_filter1d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import TARGET_Z

files = sorted(glob.glob("data/4/*.txt"),
               key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))

frames = [200, 500]
fig, axes = plt.subplots(2, 3, figsize=(18, 9))
for row, fi in enumerate(frames):
    rf = np.loadtxt(files[fi], dtype=np.float32).T
    rf -= rf.mean(axis=0, keepdims=True)
    env = np.abs(hilbert(rf, axis=0))  # 500 x 1000
    mx = env.max()
    prof = gaussian_filter1d(env.mean(axis=1), 3)
    prof /= prof.max()

    axes[row, 0].imshow(env, cmap="magma", aspect="auto", vmin=0, vmax=np.percentile(env, 99.9))
    for s, c, lab in [(180, "cyan", "old start 180"), (500, "cyan", "old end 500"),
                      (60, "lime", "new start 60"), (380, "lime", "new end 380")]:
        axes[row, 0].axhline(s, color=c, lw=1, ls="--")
    axes[row, 0].set_title(f"frame {fi}: full envelope (500 depth samples)")
    axes[row, 0].set_ylabel("RF sample (3 um/sample)")

    axes[row, 1].plot(prof, np.arange(500), color="k", lw=1.5)
    for s, c in [(180, "cyan"), (500, "cyan"), (60, "lime"), (380, "lime")]:
        axes[row, 1].axhline(s, color=c, lw=1, ls="--")
    axes[row, 1].invert_yaxis()
    axes[row, 1].set_title(f"frame {fi}: mean envelope vs sample")
    axes[row, 1].set_xlabel("relative intensity")

    old = zoom(env[180:500], (TARGET_Z / 320.0, 1.0), order=3)
    new = zoom(env[60:380], (TARGET_Z / 320.0, 1.0), order=3)
    both = np.concatenate([old / mx, new / mx], axis=1)
    axes[row, 2].imshow(both, cmap="magma", aspect="auto", vmin=0, vmax=0.8)
    axes[row, 2].axvline(1000, color="w", lw=2)
    axes[row, 2].set_title(f"frame {fi}: old 180:500 (left) vs new 60:380 (right)")
    axes[row, 2].set_xlabel("X (1000 each)")

plt.tight_layout()
plt.savefig("fig_pam_window.png", dpi=160)
print("saved fig_pam_window.png")
