import os
import numpy as np

try:
    import h5py
except ImportError:  # 允许在没有 h5py 的机器上只跑 npy / 分析脚本
    h5py = None

from scipy.signal import hilbert
from scipy.ndimage import zoom, gaussian_filter1d
from config import *


# ---------------------------------------------------------------------------
# 光片读取器
#
# 旧版的三个致命问题（已在下面修正）：
#   1. vmin=350 完全去不掉背景：原始背景中位数约 419，99% 的像素都 >350，
#      结果 target 的背景被映射到 0.14~0.42，网络学到的是"灰色底板"。
#   2. x_coords = linspace(...) 是最近邻抽样，4766 -> 1000 会把血管抽成
#      锯齿/断线；这里改成按区间做 block-mean（抗混叠）。
#   3. 光片有沿 Z 贯穿的照明条纹；这里做温和的列偏置扣除。
#      如果条纹本身低于噪声，profile 会接近 0（等价于 no-op），不会误删血管。
# ---------------------------------------------------------------------------

def _open_volume(path):
    if path.endswith(".npy"):
        return np.load(path, mmap_mode="r")
    if h5py is None:
        raise ImportError("读取 .ims 需要 h5py；请先 pip install h5py")
    return h5py.File(path, "r")["DataSet/ResolutionLevel 0/TimePoint 0/Channel 0/Data"]


def _block_mean_x(img, out_w=TARGET_X):
    """4766 -> 1000 的抗混叠降采样（区间平均，而不是最近邻）。"""
    h, w = img.shape
    if w == out_w:
        return img.astype(np.float32, copy=False)
    edges = np.linspace(0, w, out_w + 1).astype(np.int64)
    if np.any(np.diff(edges) <= 0):
        # 极少数宽度不能被 out_w 整除的情况，退回逐列平均
        out = np.empty((h, out_w), np.float32)
        for i in range(out_w):
            a, b = edges[i], max(edges[i] + 1, edges[i + 1])
            out[:, i] = img[:, a:b].mean(axis=1)
        return out
    sums = np.add.reduceat(img, edges[:-1], axis=1)
    counts = np.diff(edges).astype(np.float32)
    return (sums / counts[None, :]).astype(np.float32)


def compute_ls_stats(ims_path, n_samples=16):
    """
    在整卷上估计三个与切片无关的标定量：
      bg          : 背景（中位数）
      col_profile : 每一列的照明条纹偏置（沿 X 平滑）
      gain        : 全卷 p99.9 信号增益
    这些量按"卷"估计，而不是按"切片"，这样训练/推理/跨鼠才一致。
    """
    vol = _open_volume(ims_path)
    n_y = vol.shape[1]
    ys = np.linspace(0, n_y - 1, min(n_samples, n_y)).astype(int)

    bgs, gains, cols = [], [], []
    for y in ys:
        raw = np.asarray(vol[0:TARGET_Z, y, :], dtype=np.float32)
        bg = float(np.percentile(raw, LS_BG_PERCENTILE))
        sig = np.maximum(raw - bg, 0.0)
        col = np.percentile(sig, 10.0, axis=0).astype(np.float32)
        sig = np.maximum(sig - col[None, :], 0.0)
        bgs.append(bg)
        cols.append(col)
        gains.append(float(np.percentile(sig, LS_GAIN_PERCENTILE)))

    bg = float(np.median(bgs))
    gain = float(np.median(gains)) * GAIN_HEADROOM
    col_profile = np.median(np.stack(cols, axis=0), axis=0)
    col_profile = gaussian_filter1d(col_profile, 5.0).astype(np.float32)

    if gain <= 1.0:  # 防止空卷/异常卷
        gain = float(np.percentile(col_profile, 99.0) + 500.0)

    return {"bg": bg, "gain": gain, "col_profile": col_profile}


class LightsheetReader:
    def __init__(self, ims_path, stats=None):
        self.ims_path = ims_path
        self._vol = None
        self._stats = stats

    @property
    def vol(self):
        if self._vol is None:
            self._vol = _open_volume(self.ims_path)
        return self._vol

    @property
    def stats(self):
        if self._stats is None:
            self._stats = compute_ls_stats(self.ims_path)
        return self._stats

    def get_xz(self, y_idx, x_start=0):
        """
        y_idx: 原图全局 Y（200..4899），与旧代码约定一致。
        返回 (457, 1000) float32，背景=0，整卷 p99.9 归一化到约 0.77
        （乘了 GAIN_HEADROOM=1.3，给最亮血管峰留余量，避免削平顶）。
        """
        y = int(y_idx) - LS_M4_Y_START
        y = int(np.clip(y, 0, self.vol.shape[1] - 1))
        raw = np.asarray(
            self.vol[0:TARGET_Z, y, x_start:x_start + 4766], dtype=np.float32
        )

        st = self.stats
        sig = np.maximum(raw - st["bg"], 0.0)
        sig = np.maximum(sig - st["col_profile"][x_start:x_start + sig.shape[1]][None, :], 0.0)
        sig = _block_mean_x(sig, TARGET_X)
        return np.clip(sig / st["gain"], 0.0, 1.0).astype(np.float32)


# ---------------------------------------------------------------------------
# 声光读取器
#
# 旧版每帧单独做 p2~p99.8 归一化，会：
#   - 把深部只有噪声的切片拉到满量程，放大噪声；
#   - 破坏切片间的绝对幅度/深度衰减，训练和推理的输入分布对不上。
# 现在改成"每帧中位数去背景 + 整卷统一 gain"，保留真实的深度衰减。
# ---------------------------------------------------------------------------

class PamReader:
    @staticmethod
    def _envelope(filepath):
        raw_rf = np.loadtxt(filepath, dtype=np.float32).T
        raw_rf = raw_rf - np.mean(raw_rf, axis=0, keepdims=True)
        env = np.abs(hilbert(raw_rf, axis=0))
        # 用包含脑表面的窗口；旧版 180:500 会把大部分帧的皮层表面切掉
        seg = env[PAM_Z_START:PAM_Z_END, :]
        return zoom(seg, (TARGET_Z / float(seg.shape[0]), 1.0), order=3)

    @staticmethod
    def get_xz(filepath, bg=None, gain=None):
        xz = PamReader._envelope(filepath)
        if bg is None:
            # 每帧中位数 = 背景/离焦雾；用"全局 gain"而不是"每帧 gain"，
            # 这样切片之间的血管幅度和深度衰减不会被抹平。
            bg = float(np.median(xz))
        if gain is None:
            gain = float(np.percentile(xz, PAM_GAIN_PERCENTILE)) * GAIN_HEADROOM
        return np.clip((xz - bg) / (gain - bg + 1e-6), 0.0, 1.0).astype(np.float32)

    @staticmethod
    def calibrate(files, n=30):
        """从整卷抽样估计统一的背景和增益。"""
        if len(files) == 0:
            raise ValueError("没有找到声光 txt 文件")
        idx = np.linspace(0, len(files) - 1, min(n, len(files))).astype(int)
        bgs, gains = [], []
        for i in idx:
            xz = PamReader._envelope(files[i])
            bgs.append(float(np.percentile(xz, PAM_BG_PERCENTILE)))
            gains.append(float(np.percentile(xz, PAM_GAIN_PERCENTILE)))
        bg = float(np.median(bgs))
        gain = float(np.median(gains)) * GAIN_HEADROOM
        if gain <= bg:
            gain = bg + 1.0
        return bg, gain
