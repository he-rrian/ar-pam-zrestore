import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import torch
from torch.utils.data import DataLoader
from dataset import PseudoPairDataset
from model import AxialNAFNet, total_loss
from config import *

def worker_init_fn(worker_id):
    import numpy as np
    np.random.seed(np.random.get_state()[1][0] + worker_id)

if __name__ == "__main__":
    # 注意 Y 起点和终点，避免近邻泄露
    train_y_indices = list(range(LS_M4_Y_START + 15, TRAIN_Y_END, 3))
    val_y_indices   = list(range(VAL_Y_START, VAL_Y_END, 5))

    train_ds = PseudoPairDataset(IMS_M4_NPY, train_y_indices)
    val_ds   = PseudoPairDataset(IMS_M4_NPY, val_y_indices)

    train_loader = DataLoader(train_ds, batch_size=4, shuffle=True, 
                            num_workers=4, pin_memory=True, worker_init_fn=worker_init_fn)
    val_loader   = DataLoader(val_ds, batch_size=4, shuffle=False, 
                            num_workers=2, pin_memory=True, worker_init_fn=worker_init_fn)

    model = AxialNAFNet().cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=60, eta_min=1e-6)

    best_val_loss = float("inf")

    for epoch in range(1, 61):
        model.train()
        train_loss = 0.0
        for X, Y in train_loader:
            X, Y = X.cuda(non_blocking=True), Y.cuda(non_blocking=True)
            pred = model(X)
            loss = total_loss(pred, Y)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_loss += loss.item()

        scheduler.step()
        train_loss /= len(train_loader)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X_v, Y_v in val_loader:
                X_v, Y_v = X_v.cuda(non_blocking=True), Y_v.cuda(non_blocking=True)
                val_loss += total_loss(model(X_v), Y_v).item()
        val_loss /= len(val_loader)

        print(f"Epoch [{epoch:02d}/60] | Train: {train_loss:.5f} | Val: {val_loss:.5f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), "best_mfixed.pth")
            print(f"  >>> Best Model Saved (Val Loss: {best_val_loss:.5f})")