"""纯 NumPy 的物理退化模拟（不依赖 torch，方便单独验证/可视化）。"""

import numpy as np
from scipy.ndimage import gaussian_filter, gaussian_filter1d

from config import (
    PSF_SIGMA_Z, PSF_SIGMA_X, ATT_EXP,
    SPECKLE_SCALE, NOISE_SIGMA, NOISE_BLUR,
)


def generate_pseudo_pam(ls_xz, rng=None, sigma_z=None, sigma_x=None, att_exp=None,
                        speckle_scale=None, noise_sigma=None, noise_blur=None):
    """
    物理退化：y = A(z) * (PSF_z * PSF_x * x) + speckle + noise

    与旧版的三个区别：
      1. PSF_z 默认 2.4~5.2 px（实测标定），不是 7.6 px；
      2. 深度衰减默认 exp(-1.3 z)，不是 exp(-0.4 z)；
      3. 额外返回"无噪声退化图" clean，供物理一致性损失使用；
         旧版把带噪输入直接当物理约束目标，等于逼网络复现散斑。
    """
    if rng is None:
        rng = np.random.default_rng()
    if sigma_z is None:
        sigma_z = PSF_SIGMA_Z
    if sigma_x is None:
        sigma_x = PSF_SIGMA_X
    if att_exp is None:
        att_exp = ATT_EXP
    if speckle_scale is None:
        speckle_scale = SPECKLE_SCALE
    if noise_sigma is None:
        noise_sigma = NOISE_SIGMA
    if noise_blur is None:
        noise_blur = NOISE_BLUR

    # 横向匹配到 AR-PAM 的分辨率；轴向保持光片的锐度（这是要恢复的目标）
    target = gaussian_filter(ls_xz, sigma=(0.0, float(sigma_x)))

    # 轴向超声 PSF 展宽
    blurred_z = gaussian_filter1d(target, sigma=float(sigma_z), axis=0)

    # 深度衰减
    z_norm = np.linspace(0.0, 1.0, target.shape[0])[:, None]
    attenuation = np.exp(-float(att_exp) * z_norm)

    clean = (blurred_z * attenuation).astype(np.float32)

    # 乘性 Rayleigh 散斑 + 加性电子噪声；真实噪声被换能器带宽平滑，不是白噪声
    speckle = rng.rayleigh(speckle_scale, size=clean.shape).astype(np.float32)
    gauss = rng.normal(0.0, noise_sigma, size=clean.shape).astype(np.float32)
    if noise_blur and noise_blur > 0:
        speckle = gaussian_filter1d(speckle, float(noise_blur), axis=0) * 1.3
        gauss = gaussian_filter1d(gauss, float(noise_blur), axis=0) * 1.3

    pseudo = np.clip(clean + clean * speckle + gauss, 0.0, 1.0).astype(np.float32)

    return pseudo, target.astype(np.float32), clean
