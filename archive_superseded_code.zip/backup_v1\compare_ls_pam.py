import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import *
from data_reader import LightsheetReader


def compare_ls_vs_pam(ls_npy_path, raw_pam_path, enh_pam_path, mouse_name="Mouse4"):
    raw = np.load(raw_pam_path)
    enh = np.load(enh_pam_path)
    n_pam = raw.shape[0]
    ls_reader = LightsheetReader(ls_npy_path)

    # 旧代码把 PAM frame index 直接当成 LS 的 Y index —— 这是错的。
    # PAM: 1 frame = 10 um; LS: 1 slice = 2.1 um; 比值约 4.7。
    # 物理上对应的 LS npy 行号是 y * (4700 / n_pam)。
    y_samples = [200, 500, 800]

    fig, axes = plt.subplots(len(y_samples), 3, figsize=(18, 5 * len(y_samples)))
    fig.suptitle(f"{mouse_name}: Light-Sheet vs Raw PAM vs Enhanced PAM", fontsize=20)

    for i, y_idx in enumerate(y_samples):
        ls_y = int(round(y_idx * LS_M4_Y_TOTAL / n_pam))
        ls_y = min(ls_y, LS_M4_Y_TOTAL - 1)

        # 光片真值（注意：这是"物理上最近"的层，不代表已经配准）
        ls_xz = ls_reader.get_xz(ls_y + LS_M4_Y_START, LS_M4_X_START)

        p_idx = min(y_idx, n_pam - 1)
        raw_img = raw[p_idx]
        enh_img = enh[p_idx]

        axes[i, 0].imshow(ls_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
        axes[i, 0].set_title(f"Light-Sheet GT (Y={ls_y}, {ls_y * 2.1 / 1000:.2f} mm)")
        axes[i, 0].set_ylabel("Depth Z")

        axes[i, 1].imshow(raw_img, cmap="magma", aspect="auto", vmin=0, vmax=1)
        axes[i, 1].set_title(f"Raw PAM (frame {p_idx}, {p_idx * 10 / 1000:.2f} mm)")

        axes[i, 2].imshow(enh_img, cmap="magma", aspect="auto", vmin=0, vmax=1)
        axes[i, 2].set_title(f"Enhanced PAM (frame {p_idx})")

    plt.tight_layout()
    plt.savefig(f"compare_LS_PAM_{mouse_name}.png", dpi=250)
    plt.close()
    print(f"✅ 对比图已保存：compare_LS_PAM_{mouse_name}.png")
    print("   ⚠️ 若两套数据 FOV 未配准，这里的并排图只能看纹理/锐度，不能逐像素比较。")


if __name__ == "__main__":
    compare_ls_vs_pam(
        ls_npy_path=IMS_M4_NPY,
        raw_pam_path=CACHE_M4_PATH,
        enh_pam_path=os.path.join(DATA_DIR, "mouse4_enhanced.npy"),
        mouse_name="Mouse4",
    )
    compare_ls_vs_pam(
        ls_npy_path=IMS_M1_NPY,
        raw_pam_path=CACHE_M1_PATH,
        enh_pam_path=os.path.join(DATA_DIR, "mouse1_enhanced.npy"),
        mouse_name="Mouse1",
    )
