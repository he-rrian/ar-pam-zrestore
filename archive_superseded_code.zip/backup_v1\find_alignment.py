import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import CACHE_M1_PATH, IMS_M1_NPY, LS_M4_Y_START, LS_M4_Y_TOTAL
from data_reader import LightsheetReader

# 固定要观察的 PAM 切片
pam_idx = 500
raw = np.load(CACHE_M1_PATH)
raw_xz = raw[pam_idx]

# 旧版这里搜的是 LS Y=800..1800，但 PAM frame 500 物理上对应 LS npy Y≈2350，
# 所以之前根本没搜到正确层。现在按 4.7x 的物理映射在正确位置附近搜。
ls_center = int(round(pam_idx * LS_M4_Y_TOTAL / raw.shape[0]))
ls_y_range = [ls_center + d for d in (-800, -400, -200, 0, 200, 400, 800)]
ls_y_range = [min(max(y, 0), LS_M4_Y_TOTAL - 1) for y in ls_y_range]

reader = LightsheetReader(IMS_M1_NPY)

fig, axes = plt.subplots(2, 4, figsize=(20, 10))
axes = axes.flatten()

axes[0].imshow(raw_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
axes[0].set_title(f"RAW PAM (frame {pam_idx}, {pam_idx * 10 / 1000:.2f} mm)",
                  color="red", fontweight="bold")

for i, y in enumerate(ls_y_range):
    try:
        # get_xz 接收的是原图全局 Y，所以加 LS_M4_Y_START
        ls_xz = reader.get_xz(y + LS_M4_Y_START, 0)
        axes[i + 1].imshow(ls_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
        axes[i + 1].set_title(f"Light-Sheet (npy Y={y}, {y * 2.1 / 1000:.2f} mm)")
    except Exception as e:
        axes[i + 1].text(0.5, 0.5, f"Read Error\n{e}", ha="center")

plt.tight_layout()
plt.savefig("find_ls_y.png", dpi=250)
print("已生成对齐查找图: find_ls_y.png")
print("提示：并排图只能用于找大致对应的层；若 FOV 本身未配准，仍需扫描元数据确认。")
