import os

# ================== 路径配置 ==================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

IMS_M4_NPY     = os.path.join(DATA_DIR, "4_subset.npy")
IMS_M1_NPY     = os.path.join(DATA_DIR, "1_subset.npy")

PAM_M1_TXT_DIR = os.path.join(DATA_DIR, "1")
PAM_M4_TXT_DIR = os.path.join(DATA_DIR, "4")
CACHE_M1_PATH  = os.path.join(DATA_DIR, "1_pam_cache.npy")
CACHE_M4_PATH  = os.path.join(DATA_DIR, "4_pam_cache.npy")

# ================== 物理与网格参数 ==================
TARGET_Z = 457
TARGET_X = 1000

# 光片裁剪范围
LS_M4_Z_START = 0          
LS_M4_X_START = 0            # 🚨 铁律：必须为 0，数组总宽就是 4766
LS_M4_Y_START = 200          # npy 里 Y=0 对应原图 Y=200
LS_M4_Y_TOTAL = 4700

# 训练/验证切分（避免近邻泄漏）
TRAIN_Y_END = int(LS_M4_Y_START + LS_M4_Y_TOTAL * 0.8)   # 3960
VAL_Y_START = TRAIN_Y_END + 50                            # 4010
VAL_Y_END   = LS_M4_Y_START + LS_M4_Y_TOTAL - 15          # 4885

# 2.5D 与退化核
Y_STEP_LS     = 5
SIGMA_SHALLOW = 6.8
SIGMA_MID     = 7.6
SIGMA_DEEP    = 8.9