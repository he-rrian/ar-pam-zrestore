"""Generate orthogonal MIPs (XZ over Y, YZ over X) for LS and PAM."""

import glob
import os
import re

import numpy as np
from scipy.signal import hilbert
from scipy.ndimage import zoom
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import IMS_M4_NPY, PAM_M4_TXT_DIR, TARGET_Z, TARGET_X
from data_reader import compute_ls_stats, PamReader

# ---------------- LS orthogonal MIPs ----------------
stats = compute_ls_stats(IMS_M4_NPY, n_samples=8)
bg, gain = stats["bg"], stats["gain"]
a = np.load(IMS_M4_NPY, mmap_mode="r")
Zs, Ys, Xs = a.shape
edges = np.linspace(0, Xs, TARGET_X + 1).astype(np.int64)
counts = np.diff(edges).astype(np.float32)

mip_xz = np.zeros((Zs, TARGET_X), np.float32)   # max over Y
mip_yz = np.zeros((Zs, Ys), np.float32)         # max over X

for y0 in range(0, Ys, 50):
    y1 = min(y0 + 50, Ys)
    block = np.asarray(a[:, y0:y1, :], dtype=np.float32)
    block -= bg
    np.maximum(block, 0, out=block)
    # X block-mean then max over Y
    sums = np.add.reduceat(block, edges[:-1], axis=2)
    bm = sums / counts[None, None, :]
    mip_xz = np.maximum(mip_xz, bm.max(axis=1))
    # max over X then max over Y (for YZ)
    mip_yz[:, y0:y1] = block.max(axis=2)
    print("LS chunk", y0, "/", Ys)

mip_xz = np.clip(mip_xz / gain, 0, 1)
mip_yz = np.clip(mip_yz / gain, 0, 1)

# ---------------- PAM orthogonal MIPs ----------------
files = sorted(glob.glob(os.path.join(PAM_M4_TXT_DIR, "*.txt")),
               key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))
_, pgain = PamReader.calibrate(files, n=24)

mip_xz_p = np.zeros((TARGET_Z, TARGET_X), np.float32)
mip_yz_p = np.zeros((TARGET_Z, len(files)), np.float32)
for i, f in enumerate(files):
    xz = PamReader._envelope(f)
    xz = np.clip((xz - np.median(xz)) / pgain, 0, 1)
    mip_xz_p = np.maximum(mip_xz_p, xz)
    mip_yz_p[:, i] = xz.max(axis=1)
    if i % 100 == 0:
        print("PAM frame", i, "/", len(files))

# YZ: LS has 4700 Y rows, PAM has 1000 frames; downsample LS Y to 1000 for display
yedges = np.linspace(0, Ys, 1001).astype(np.int64)
ls_yz = np.stack([mip_yz[:, yedges[i]:max(yedges[i] + 1, yedges[i + 1])].max(axis=1)
                  for i in range(1000)], axis=1)

fig, ax = plt.subplots(2, 2, figsize=(16, 8))
ax[0, 0].imshow(mip_xz, cmap="magma", aspect="auto", vmin=0, vmax=np.percentile(mip_xz, 99.5))
ax[0, 0].set_title("LS XZ MIP (max over all Y) — full depth view")
ax[0, 0].set_xlabel("X"); ax[0, 0].set_ylabel("Z")

ax[0, 1].imshow(mip_xz_p, cmap="magma", aspect="auto", vmin=0, vmax=np.percentile(mip_xz_p, 99.5))
ax[0, 1].set_title("PAM XZ MIP (max over all frames) — full depth view")
ax[0, 1].set_xlabel("X")

ax[1, 0].imshow(ls_yz, cmap="magma", aspect="auto", vmin=0, vmax=np.percentile(ls_yz, 99.5))
ax[1, 0].set_title("LS YZ MIP (max over all X) — full depth view")
ax[1, 0].set_xlabel("Y (1000 bins)"); ax[1, 0].set_ylabel("Z")

ax[1, 1].imshow(mip_yz_p, cmap="magma", aspect="auto", vmin=0, vmax=np.percentile(mip_yz_p, 99.5))
ax[1, 1].set_title("PAM YZ MIP (max over all X) — full depth view")
ax[1, 1].set_xlabel("Y (frames)")

plt.tight_layout()
plt.savefig("fig_orthogonal_mips.png", dpi=160)
np.save("mip_xz_ls.npy", mip_xz)
np.save("mip_xz_pam.npy", mip_xz_p)
print("saved fig_orthogonal_mips.png")
