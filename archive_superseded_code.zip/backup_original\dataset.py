import os
import numpy as np
import torch
from scipy.ndimage import gaussian_filter1d
from torch.utils.data import Dataset
from config import *
from data_reader import LightsheetReader

def generate_pseudo_pam(ls_xz):
    """ls_xz 已经是标准的 (457, 1000) 真实脑皮层血管切片"""
    # 1. 轴向超声 PSF 展宽
    blurred_z = gaussian_filter1d(ls_xz, sigma=SIGMA_MID, axis=0)

    # 2. 深度声学/光学指数衰减
    z_norm = np.linspace(0, 1, TARGET_Z)[:, None]
    attenuation = np.exp(-0.4 * z_norm)
    attenuated = blurred_z * attenuation

    # 3. 纯正超声 Rayleigh 乘性散斑 + 弱高斯背景
    speckle = np.random.rayleigh(scale=0.035, size=attenuated.shape)
    gaussian_noise = np.random.normal(0, 0.012, attenuated.shape)
    noisy = attenuated + (attenuated * speckle) + gaussian_noise

    return np.clip(noisy, 0.0, 1.0).astype(np.float32), ls_xz.astype(np.float32)


class PseudoPairDataset(Dataset):
    def __init__(self, ims_path, y_center_indices):
        self.ims_path = ims_path
        self.y_center_indices = y_center_indices
        self.reader = None

    def __len__(self):
        return len(self.y_center_indices)

    def __getitem__(self, idx):
        if self.reader is None:
            self.reader = LightsheetReader(self.ims_path)

        y_center = self.y_center_indices[idx]
        channels = []
        y_hr_target = None

        offsets = [-2 * Y_STEP_LS, -1 * Y_STEP_LS, 0, 1 * Y_STEP_LS, 2 * Y_STEP_LS]
        for offset in offsets:
            ls_xz = self.reader.get_xz(y_center + offset, LS_M4_X_START)
            x_lr, y_hr = generate_pseudo_pam(ls_xz)
            channels.append(x_lr)
            if offset == 0:
                y_hr_target = y_hr

        return torch.from_numpy(np.stack(channels, axis=0)), torch.from_numpy(y_hr_target[np.newaxis, ...])