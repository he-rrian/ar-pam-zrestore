import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sub4 = np.load("./data/4_subset.npy", mmap_mode="r")
sub1 = np.load("./data/1_subset.npy", mmap_mode="r")

# 取 Y 轴中心切片
s4 = sub4[:, 2350, :]
s1 = sub1[:, 2350, :]

fig, ax = plt.subplots(1, 2, figsize=(16, 6))

# 使用合理的背景下限 vmin=350，避免发橙
im0 = ax[0].imshow(
    s1,
    cmap="magma",
    aspect="auto",
    vmin=350,
    vmax=np.percentile(s1[s1 > 350], 99.5),
)
ax[0].set_title("Mouse 1 Real Cortex (Clean)")
ax[0].set_ylabel("Depth Z (960 μm)")
ax[0].set_xlabel("Width X")

im1 = ax[1].imshow(
    s4,
    cmap="magma",
    aspect="auto",
    vmin=350,
    vmax=np.percentile(s4[s4 > 350], 99.5),
)
ax[1].set_title("Mouse 4 Real Cortex (Clean, Flipped)")
ax[1].set_ylabel("Depth Z (960 μm)")
ax[1].set_xlabel("Width X")

plt.tight_layout()
plt.savefig("cortex_verified_clean.png", dpi=200)
print("✅ 验证图已保存为 cortex_verified_clean.png！")