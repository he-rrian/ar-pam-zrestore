import h5py
import numpy as np
from scipy.signal import hilbert
from scipy.ndimage import zoom
from config import *

class LightsheetReader:
    def __init__(self, ims_path):
        self.ims_path = ims_path
        self._vol = None
        # 极速抽取坐标，避免 scipy.zoom 卡死 DataLoader
        self.x_coords = np.linspace(0, 4765, TARGET_X).astype(np.int32)

    @property
    def vol(self):
        if self._vol is None:
            if self.ims_path.endswith(".npy"):
                self._vol = np.load(self.ims_path, mmap_mode='r')
            else:
                self._vol = h5py.File(self.ims_path, "r")["DataSet/ResolutionLevel 0/TimePoint 0/Channel 0/Data"]
        return self._vol

    def get_xz(self, y_idx, x_start):
        # npy 已经是 (457, 4700, 4766)，直接全取，无需 zoom
        raw_xz = self.vol[0 : TARGET_Z, y_idx - LS_M4_Y_START, x_start : x_start + 4766].astype(np.float32)

        # 完美色阶归一化（带防空兜底保护）
        vmin = 350.0
        foreground = raw_xz[raw_xz > vmin]
        if len(foreground) > 100:
            vmax = np.percentile(foreground, 99.5)
        else:
            vmax = vmin + 500.0

        xz_norm = np.clip((raw_xz - vmin) / (vmax - vmin + 1e-6), 0.0, 1.0)
        
        # 极速列抽取
        return xz_norm[:, self.x_coords]

class PamReader:
    """声光读取器：去基线 + Hilbert 包络 + 死区截取 + Z 轴重采样"""
    @staticmethod
    def get_xz(filepath):
        raw_rf = np.loadtxt(filepath, dtype=np.float32).T
        raw_rf = raw_rf - np.mean(raw_rf, axis=0, keepdims=True)
        env = np.abs(hilbert(raw_rf, axis=0))
        valid_env = env[180:500, :]
        xz_resampled = zoom(valid_env, (TARGET_Z / 320.0, 1.0), order=3)
        p_min, p_max = np.percentile(xz_resampled, 2.0), np.percentile(xz_resampled, 99.8)
        return np.clip((xz_resampled - p_min) / (p_max - p_min + 1e-6), 0.0, 1.0).astype(np.float32)