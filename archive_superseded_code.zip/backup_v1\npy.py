import os
import h5py
import numpy as np

# ================= 路径配置 =================
IMS_M4_PATH = "./data/4.ims"
IMS_M1_PATH = "./data/1.ims"
OUT_M4_PATH = "./data/4_subset.npy"
OUT_M1_PATH = "./data/1_subset.npy"

# 统一输出形状: (Z=457, Y=4700, X=4766), uint16 格式
TARGET_SHAPE = (457, 4700, 4766)
CHUNK_SIZE = 100  # 每次只读 100 个 Y 切片，内存占用仅约 430 MB，绝不爆内存！


def extract_mouse4_chunked():
    """提取小鼠 4: Z=1540~1997, 沿 Z 轴翻转 (头顶朝上)"""
    print(f"\n[1/2] 正在分块提取 小鼠 4 (带 Z 轴翻转)...")
    if not os.path.exists(IMS_M4_PATH):
        print(f"❌ 找不到文件: {IMS_M4_PATH}")
        return

    # 在磁盘上直接分配 19.1 GB 的空文件
    out_mmap = np.lib.format.open_memmap(
        OUT_M4_PATH, mode="w+", dtype=np.uint16, shape=TARGET_SHAPE
    )

    with h5py.File(IMS_M4_PATH, "r") as f:
        vol = f["DataSet/ResolutionLevel 0/TimePoint 0/Channel 0/Data"]
        x_start = (vol.shape[2] - TARGET_SHAPE[2]) // 2
        x_end = x_start + TARGET_SHAPE[2]

        # 沿 Y 轴分块流式提取
        y_total = TARGET_SHAPE[1]
        for y_offset in range(0, y_total, CHUNK_SIZE):
            y_len = min(CHUNK_SIZE, y_total - y_offset)
            y_src_start = 200 + y_offset
            y_src_end = y_src_start + y_len

            # 1. 只读取当前 100 层的小块
            chunk = vol[1540:1997, y_src_start:y_src_end, x_start:x_end]

            # 2. 沿 Z 轴切片翻转 (chunk[::-1, :, :])，让小鼠头顶朝上
            chunk_flipped = chunk[::-1, :, :]

            # 3. 写入磁盘对应的局部位置
            out_mmap[:, y_offset : y_offset + y_len, :] = chunk_flipped

            print(
                f"  -> 小鼠 4 已完成进度: {y_offset + y_len}/{y_total} 层 Y 切片..."
            )

    out_mmap.flush()
    del out_mmap
    print(f"✅ 小鼠 4 提取并翻转完成！已保存至 {OUT_M4_PATH}")


def extract_mouse1_chunked():
    """提取小鼠 1: Z=50~507, 正立无需翻转"""
    print(f"\n[2/2] 正在分块提取 小鼠 1 (正立)...")
    if not os.path.exists(IMS_M1_PATH):
        print(f"❌ 找不到文件: {IMS_M1_PATH}")
        return

    out_mmap = np.lib.format.open_memmap(
        OUT_M1_PATH, mode="w+", dtype=np.uint16, shape=TARGET_SHAPE
    )

    with h5py.File(IMS_M1_PATH, "r") as f:
        vol = f["DataSet/ResolutionLevel 0/TimePoint 0/Channel 0/Data"]
        x_start = (vol.shape[2] - TARGET_SHAPE[2]) // 2
        x_end = x_start + TARGET_SHAPE[2]

        y_total = TARGET_SHAPE[1]
        for y_offset in range(0, y_total, CHUNK_SIZE):
            y_len = min(CHUNK_SIZE, y_total - y_offset)
            y_src_start = 200 + y_offset
            y_src_end = y_src_start + y_len

            # 读取当前小块并直接写入磁盘 (小鼠1本就是正立，无需翻转)
            chunk = vol[50:507, y_src_start:y_src_end, x_start:x_end]
            out_mmap[:, y_offset : y_offset + y_len, :] = chunk

            print(
                f"  -> 小鼠 1 已完成进度: {y_offset + y_len}/{y_total} 层 Y 切片..."
            )

    out_mmap.flush()
    del out_mmap
    print(f"✅ 小鼠 1 提取完成！已保存至 {OUT_M1_PATH}")


if __name__ == "__main__":
    extract_mouse4_chunked()
    extract_mouse1_chunked()