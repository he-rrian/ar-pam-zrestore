import numpy as np, glob, re, os
from scipy.signal import hilbert
from scipy.ndimage import zoom
from config import PAM_Z_START, PAM_Z_END, TARGET_Z

files = sorted(glob.glob("data/4/*.txt"), key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))
prof = []
for i in range(0, len(files), 25):
    rf = np.loadtxt(files[i], dtype=np.float32).T
    rf -= rf.mean(0, keepdims=True)
    env = np.abs(hilbert(rf, axis=0))[PAM_Z_START:PAM_Z_END]
    e = zoom(env, (TARGET_Z / float(env.shape[0]), 1.0), order=3)
    p = e.mean(axis=1)
    prof.append(p / p.max())
prof = np.median(np.stack(prof), axis=0)
print("z   rel")
for z in range(0, TARGET_Z, 40):
    print("%3d %.3f" % (z, prof[z]))
# fit log-linear from z=150..450
z = np.arange(150, 457)
mask = prof[150:] > 0.01
coef = np.polyfit(z[mask], np.log(prof[150:][mask]), 1)
print("fit slope", coef[0], "-> att_exp per full Z", -coef[0] * 457)
