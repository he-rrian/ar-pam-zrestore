import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from config import CACHE_M4_PATH # 指向小鼠4的cache

raw = np.load(CACHE_M4_PATH)
enh = np.load("mouse4_enhanced.npy") # 刚刚推理出的结果

print(f"数据形状: Raw={raw.shape}, Enhanced={enh.shape}")

# ----------------- ① 生成全脑皮层 XY 俯视 MIP 投影 -----------------
raw_mip_xy = np.max(raw, axis=1)
enh_mip_xy = np.max(enh, axis=1)

fig, axes = plt.subplots(1, 2, figsize=(14, 7))
axes[0].imshow(raw_mip_xy, cmap='magma', aspect='auto')
axes[0].set_title("Raw PAM - XY Max Projection (MIP)")

axes[1].imshow(enh_mip_xy, cmap='magma', aspect='auto')
axes[1].set_title("Enhanced PAM - XY Max Projection (MIP)")

plt.tight_layout()
plt.savefig("result_MIP_XY.png", dpi=300)
plt.close()
print("已保存 全脑血管网俯视大图: result_MIP_XY.png")

# ----------------- ② 抽样对比不同 Y 层的 XZ 截面 -----------------
y_samples = [200, 400, 600, 800]
fig, axes = plt.subplots(len(y_samples), 2, figsize=(12, 3 * len(y_samples)))

for idx, y in enumerate(y_samples):
    y_idx = min(y, len(raw) - 1)
    
    # 原图
    axes[idx, 0].imshow(raw[y_idx], cmap='magma', aspect='auto')
    axes[idx, 0].set_title(f"Raw PAM (Y={y_idx})")
    
    # 增强图
    axes[idx, 1].imshow(enh[y_idx], cmap='magma', aspect='auto')
    axes[idx, 1].set_title(f"Enhanced PAM (Y={y_idx})")
    
plt.tight_layout()
plt.savefig("result_slices_XZ.png", dpi=300)
plt.close()
print("已保存 多层 XZ 截面对比图: result_slices_XZ.png")