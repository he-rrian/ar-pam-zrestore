import torch
import torch.nn as nn
import torch.nn.functional as F

class AxialBlock(nn.Module):
    def __init__(self, c, kz=9, kx=3, dilation=1):
        super().__init__()
        pad_z = (kz // 2) * dilation
        pad_x = kx // 2
        self.conv1 = nn.Conv2d(c, c, (kz, kx), padding=(pad_z, pad_x), dilation=(dilation, 1))
        self.norm = nn.GroupNorm(4, c)
        self.act = nn.GELU()
        self.conv2 = nn.Conv2d(c, c, 3, padding=1)

    def forward(self, x):
        return x + self.conv2(self.act(self.norm(self.conv1(x))))

class AxialNAFNet(nn.Module):
    def __init__(self, in_ch=5, base=32):
        super().__init__()
        self.stem = nn.Conv2d(in_ch, base, 3, padding=1)
        dilations = [1, 2, 4, 1, 2, 4]
        self.blocks = nn.Sequential(*[AxialBlock(base, kz=9, kx=3, dilation=d) for d in dilations])
        self.head = nn.Sequential(
            nn.Conv2d(base, base // 2, 3, padding=1),
            nn.GELU(),
            nn.Conv2d(base // 2, 1, 3, padding=1)
        )
        self.res_weight = nn.Parameter(torch.tensor(0.0))

    def forward(self, x):
        h = self.blocks(self.stem(x))
        w = torch.sigmoid(self.res_weight)
        return torch.clamp(self.head(h) + w * x[:, 2:3, :, :], 0.0, 1.0)


def total_loss(pred, target, lam_mean=0.05, lam_grad=1.2, lam_laplace=0.1):
    # 1. 基础空间损失 (Charbonnier)
    loss_spatial = torch.mean(torch.sqrt((pred - target) ** 2 + 1e-3))

    # 2. 能量防黑保险
    loss_mean = torch.abs(torch.mean(pred) - torch.mean(target))

    # 3. 强一阶梯度 (1.2，强制切出悬崖般的血管边缘！)
    grad_p = pred[:, :, 1:, :] - pred[:, :, :-1, :]
    grad_t = target[:, :, 1:, :] - target[:, :, :-1, :]
    loss_grad = F.l1_loss(grad_p, grad_t)

    # 4. 二阶拉普拉斯 (0.1，收窄峰顶)
    lap_p = pred[:, :, 2:, :] - 2 * pred[:, :, 1:-1, :] + pred[:, :, :-2, :]
    lap_t = target[:, :, 2:, :] - 2 * target[:, :, 1:-1, :] + target[:, :, :-2, :]
    loss_laplace = F.l1_loss(lap_p, lap_t)

    return (
        loss_spatial
        + lam_mean * loss_mean
        + lam_grad * loss_grad
        + lam_laplace * loss_laplace
    )