import os
import numpy as np
import torch
from torch.utils.data import Dataset

from config import *
from data_reader import LightsheetReader, compute_ls_stats
from simulate import generate_pseudo_pam


class PseudoPairDataset(Dataset):
    def __init__(self, ims_path, y_center_indices, randomize=True):
        self.ims_path = ims_path
        self.y_center_indices = y_center_indices
        self.randomize = randomize
        self.reader = None
        # 在主进程里算一次，避免每个 worker 重复扫描 20GB 的 npy
        self.stats = compute_ls_stats(ims_path)

    def __len__(self):
        return len(self.y_center_indices)

    def __getitem__(self, idx):
        if self.reader is None:
            self.reader = LightsheetReader(self.ims_path, stats=self.stats)

        rng = np.random.default_rng()
        if self.randomize:
            sigma_z = float(rng.uniform(PSF_SIGMA_Z_MIN, PSF_SIGMA_Z_MAX))
            sigma_x = float(rng.uniform(PSF_SIGMA_X_MIN, PSF_SIGMA_X_MAX))
            att_exp = float(rng.uniform(ATT_EXP_MIN, ATT_EXP_MAX))
            speckle_scale = float(rng.uniform(SPECKLE_SCALE_MIN, SPECKLE_SCALE_MAX))
            noise_sigma = float(rng.uniform(NOISE_SIGMA_MIN, NOISE_SIGMA_MAX))
        else:
            sigma_z, sigma_x, att_exp = PSF_SIGMA_Z, PSF_SIGMA_X, ATT_EXP
            speckle_scale, noise_sigma = SPECKLE_SCALE, NOISE_SIGMA

        y_center = self.y_center_indices[idx]
        channels = []
        target = None
        clean_center = None

        offsets = [-2 * Y_STEP_LS, -1 * Y_STEP_LS, 0, 1 * Y_STEP_LS, 2 * Y_STEP_LS]
        for offset in offsets:
            ls_xz = self.reader.get_xz(y_center + offset, LS_M4_X_START)
            x_lr, y_hr, clean = generate_pseudo_pam(
                ls_xz, rng=rng, sigma_z=sigma_z, sigma_x=sigma_x, att_exp=att_exp,
                speckle_scale=speckle_scale, noise_sigma=noise_sigma,
            )
            channels.append(x_lr)
            if offset == 0:
                target = y_hr
                clean_center = clean

        X = torch.from_numpy(np.stack(channels, axis=0))
        Y = torch.from_numpy(target[np.newaxis, ...])
        C = torch.from_numpy(clean_center[np.newaxis, ...])
        meta = torch.tensor([sigma_z, sigma_x, att_exp], dtype=torch.float32)
        return X, Y, C, meta
