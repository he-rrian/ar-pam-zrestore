import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from dataset import PseudoPairDataset
from config import IMS_M4_PATH

if __name__ == "__main__":
    y_positions = [1000, 2000, 3000]
    ds = PseudoPairDataset(IMS_M4_PATH, y_positions)

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    for i, y_idx in enumerate(y_positions):
        X, Y = ds[i]
        axes[i].imshow(Y[0].numpy(), cmap="magma", aspect="auto")
        axes[i].set_title(f"Y index: {y_idx}")
        axes[i].set_xlabel("X (10 mm)")
        axes[i].set_ylabel("Z (960 μm)")

    plt.tight_layout()
    plt.savefig("verify_vessels_final.png", dpi=200)
    print("最终验证图已保存 verify_vessels_final.png")