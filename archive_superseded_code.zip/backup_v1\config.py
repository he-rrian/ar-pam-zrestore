import os

# ================== 路径配置 ==================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

IMS_M4_NPY     = os.path.join(DATA_DIR, "4_subset.npy")
IMS_M1_NPY     = os.path.join(DATA_DIR, "1_subset.npy")

PAM_M1_TXT_DIR = os.path.join(DATA_DIR, "1")
PAM_M4_TXT_DIR = os.path.join(DATA_DIR, "4")
CACHE_M1_PATH  = os.path.join(DATA_DIR, "1_pam_cache.npy")
CACHE_M4_PATH  = os.path.join(DATA_DIR, "4_pam_cache.npy")

# ================== 物理与网格参数 ==================
TARGET_Z = 457
TARGET_X = 1000

# 光片裁剪范围
LS_M4_Z_START = 0
LS_M4_X_START = 0            # 必须为 0，数组总宽就是 4766
LS_M4_Y_START = 200          # npy 里 Y=0 对应原图 Y=200
LS_M4_Y_TOTAL = 4700

# 训练/验证切分（避免近邻泄漏）
TRAIN_Y_END = int(LS_M4_Y_START + LS_M4_Y_TOTAL * 0.8)   # 3960
VAL_Y_START = TRAIN_Y_END + 50                            # 4010
VAL_Y_END   = LS_M4_Y_START + LS_M4_Y_TOTAL - 15          # 4885

# 2.5D 与退化核
Y_STEP_LS     = 5

# AR-PAM 的 RF 深度窗口（单位：RF sample，3 um/sample）
# 旧代码用 180:500，但实测皮层表面回波在 sample 117~212，
# 180 会把大部分帧的脑表面切掉（这正是"弧顶被裁"的原因）。
PAM_Z_START   = 60
PAM_Z_END     = 380
PAM_Z_SAMPLES = PAM_Z_END - PAM_Z_START   # 320 samples = 960 um

# =====================================================================
# 以下参数全部来自对真实 AR-PAM RF 数据的标定（见 calibrate_psf.py）
# 旧值 SIGMA_MID = 7.6 px 是从未标定的猜测，比真实 PSF 宽 2~3 倍，
# 这正是网络在真实数据上"过度反卷积"、出现 4 倍尖峰和振铃的根因。
# =====================================================================
# 轴向 PSF（457 x 1000 网格，2.1 um/px）
#   实测 304 个孤立血管峰的高斯拟合：sigma 中位数 2.43 RF samples
#   = 7.3 um = 3.47 px（p10 = 2.5 px, p90 = 5.4 px）
PSF_SIGMA_Z       = 3.3          # 标定值，用于可视化/基线
PSF_SIGMA_Z_MIN   = 2.3          # 训练时随机化下限
PSF_SIGMA_Z_MAX   = 4.9          # 训练时随机化上限

# 横向 PSF（AR-PAM 横向分辨率远低于 10 um 采样）
PSF_SIGMA_X       = 1.0
PSF_SIGMA_X_MIN   = 0.4
PSF_SIGMA_X_MAX   = 1.8

# 深度衰减：实测真实 PAM 在 z=450 处均值只剩 27%，旧模型 exp(-0.4z) 还剩 68%
ATT_EXP           = 1.3          # A(z) = exp(-ATT_EXP * z / Z)
ATT_EXP_MIN       = 0.9
ATT_EXP_MAX       = 1.7

# 噪声模型（真实 PAM 背景 p10 ~= 0.002，信号 p99.9 ~= 1）
SPECKLE_SCALE     = 0.05
NOISE_SIGMA       = 0.008
SPECKLE_SCALE_MIN = 0.02
SPECKLE_SCALE_MAX = 0.09
NOISE_SIGMA_MIN   = 0.004
NOISE_SIGMA_MAX   = 0.018
NOISE_BLUR        = 1.0          # 真实噪声被换能器带宽平滑，不是白噪声

# 归一化留 30% 余量，避免最亮血管峰被削成平顶
GAIN_HEADROOM = 1.3

# 光片归一化：先减背景，再除以整卷 p99.9 增益（不能用 vmin=350！）
LS_BG_PERCENTILE   = 50.0
LS_GAIN_PERCENTILE = 99.9
PAM_BG_PERCENTILE  = 5.0
PAM_GAIN_PERCENTILE = 99.9