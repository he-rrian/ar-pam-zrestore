import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import glob
import re

import numpy as np
import torch
from torch.utils.data import DataLoader

from dataset import PseudoPairDataset
from data_reader import PamReader
from model import AxialNAFNet, total_loss
from config import *


def worker_init_fn(worker_id):
    np.random.seed(np.random.get_state()[1][0] + worker_id)


def build_real_probe(txt_dir, n_ctx=5):
    """构造一个固定的真实 PAM 2.5D 探针，用来监控是否出现域崩塌。"""
    files = glob.glob(os.path.join(txt_dir, "*.txt"))
    files = [f for f in files if re.search(r"\d+", os.path.basename(f))]
    files = sorted(files, key=lambda x: int(re.search(r"\d+", os.path.basename(x)).group()))
    if len(files) < n_ctx + 2:
        return None
    bg, gain = PamReader.calibrate(files, n=24)
    mid = len(files) // 2
    idxs = list(range(mid - n_ctx // 2, mid + n_ctx // 2 + 1))
    ch = [PamReader.get_xz(files[i], bg=None, gain=gain) for i in idxs]
    X = torch.from_numpy(np.stack(ch, axis=0))[None]  # 1,5,Z,X
    return X


if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True

    train_y_indices = list(range(LS_M4_Y_START + 15, TRAIN_Y_END, 3))
    val_y_indices   = list(range(VAL_Y_START, VAL_Y_END, 5))

    # 训练集随机化 PSF/衰减/噪声；验证集固定标定值，便于比较
    train_ds = PseudoPairDataset(IMS_M4_NPY, train_y_indices, randomize=True)
    val_ds   = PseudoPairDataset(IMS_M4_NPY, val_y_indices, randomize=False)

    train_loader = DataLoader(
        train_ds, batch_size=4, shuffle=True, num_workers=4,
        pin_memory=True, worker_init_fn=worker_init_fn, drop_last=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=4, shuffle=False, num_workers=2,
        pin_memory=True, worker_init_fn=worker_init_fn,
    )

    model = AxialNAFNet().cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=60, eta_min=1e-6)

    probe = build_real_probe(PAM_M4_TXT_DIR)
    probe = probe.cuda() if probe is not None else None

    best_val_loss = float("inf")
    epochs = 60

    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        for X, Y, C, meta in train_loader:
            X = X.cuda(non_blocking=True)
            Y = Y.cuda(non_blocking=True)
            C = C.cuda(non_blocking=True)
            meta = meta.cuda(non_blocking=True)

            pred = model(X)
            loss = total_loss(
                pred, Y,
                raw_input=X[:, 2:3, :, :],
                clean_deg=C,
                meta=meta,
            )

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_loss += loss.item()

        scheduler.step()
        train_loss /= max(1, len(train_loader))

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X_v, Y_v, C_v, meta_v in val_loader:
                X_v = X_v.cuda(non_blocking=True)
                Y_v = Y_v.cuda(non_blocking=True)
                C_v = C_v.cuda(non_blocking=True)
                meta_v = meta_v.cuda(non_blocking=True)
                pred_v = model(X_v)
                val_loss += total_loss(
                    pred_v, Y_v,
                    raw_input=X_v[:, 2:3, :, :],
                    clean_deg=C_v,
                    meta=meta_v,
                ).item()
        val_loss /= max(1, len(val_loader))

        msg = f"Epoch [{epoch:02d}/{epochs}] | Train: {train_loss:.5f} | Val: {val_loss:.5f}"

        # 真实数据探针：只看输出是否塌缩/过曝，不做梯度
        if probe is not None:
            with torch.no_grad():
                out = model(probe)
                inp = probe[:, 2:3]
                empty = inp < 0.02
                msg += (
                    f" | real: in {inp.mean().item():.3f} -> out {out.mean().item():.3f}"
                    f" sat {(out > 0.99).float().mean().item():.4f}"
                    f" bg {(out[empty].std().item() if empty.any() else 0):.4f}"
                )

        print(msg)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), "best_mfixed.pth")
            print(f"  >>> Best Model Saved (Val Loss: {best_val_loss:.5f})")
