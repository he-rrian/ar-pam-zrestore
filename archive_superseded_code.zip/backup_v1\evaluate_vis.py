import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import CACHE_M1_PATH, DATA_DIR, IMS_M1_NPY, LS_M4_Y_START, LS_M4_Y_TOTAL
from data_reader import LightsheetReader

# ================= 1. 载入声光数据 =================
raw = np.load(CACHE_M1_PATH)
enh = np.load(os.path.join(DATA_DIR, "mouse1_enhanced.npy"))

pam_slice_idx = min(500, len(raw) - 1)
raw_xz = raw[pam_slice_idx]
enh_xz = enh[pam_slice_idx]

# ================= 2. 载入光片数据 =================
# PAM 1 帧 = 10 um；LS 1 层 = 2.1 um；物理对应行号约 4.7 * frame。
ls_y_idx = int(round(pam_slice_idx * LS_M4_Y_TOTAL / len(raw)))
ls_y_idx = min(ls_y_idx, LS_M4_Y_TOTAL - 1)

try:
    reader = LightsheetReader(IMS_M1_NPY)
    ls_xz = reader.get_xz(ls_y_idx + LS_M4_Y_START, 0)
except Exception as e:
    print(f"光片读取失败，将跳过光片对比。错误：{e}")
    ls_xz = np.zeros_like(raw_xz)

# ================= 3. 绘图 =================
fig, axes = plt.subplots(2, 3, figsize=(18, 10), gridspec_kw={"height_ratios": [2, 1]})

axes[0, 0].imshow(ls_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
axes[0, 0].set_title(f"Light-Sheet (npy Y={ls_y_idx}, {ls_y_idx * 2.1 / 1000:.2f} mm)")

axes[0, 1].imshow(raw_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
axes[0, 1].set_title(f"Raw PAM (frame {pam_slice_idx}, {pam_slice_idx * 10 / 1000:.2f} mm)")

axes[0, 2].imshow(enh_xz, cmap="magma", aspect="auto", vmin=0, vmax=1)
axes[0, 2].set_title(f"Enhanced PAM (frame {pam_slice_idx})")

# 注意：两套数据未必已配准，这里的同 X 剖面只能看轮廓，不能当逐像素真值
x_profile = 150
axes[1, 0].plot(ls_xz[:, x_profile], color="blue", label="Light-Sheet", linewidth=1.5)
axes[1, 0].set_title(f"Axial Profile (X={x_profile})")
axes[1, 0].legend()

axes[1, 1].plot(raw_xz[:, x_profile], color="gray", label="Raw PAM", linewidth=1.5)
axes[1, 1].set_title(f"Axial Profile (X={x_profile})")
axes[1, 1].legend()

axes[1, 2].plot(enh_xz[:, x_profile], color="red", label="Enhanced PAM", linewidth=1.5)
axes[1, 2].set_title(f"Axial Profile (X={x_profile})")
axes[1, 2].legend()

plt.tight_layout()
plt.savefig("enhancement_vs_lightsheet.png", dpi=300)
print("图像已保存至 enhancement_vs_lightsheet.png")
print("提示：LS 与 PAM 的强度尺度不同，直接比峰值没有意义；请看 FWHM（evaluate_real.py）。")
